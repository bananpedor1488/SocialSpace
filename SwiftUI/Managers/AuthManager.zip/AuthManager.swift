import Foundation
import SwiftUI

class AuthManager: ObservableObject {
    @Published var isAuthenticated = false
    @Published var currentUser: User?
    @Published var isLoading = false
    @Published var errorMessage: String?
    
    private let baseURL = "https://server-pqqy.onrender.com/api"
    private let userDefaults = UserDefaults.standard
    
    init() {
        checkAuthStatus()
    }
    
    private func checkAuthStatus() {
        if let accessToken = userDefaults.string(forKey: "accessToken"),
           let userData = userDefaults.data(forKey: "user"),
           let user = try? JSONDecoder().decode(User.self, from: userData) {
            self.currentUser = user
            self.isAuthenticated = true
        }
    }
    
    func login(email: String, password: String) async {
        await MainActor.run {
            isLoading = true
            errorMessage = nil
        }
        
        do {
            let request = AuthRequest(email: email, password: password)
            let url = URL(string: "\(baseURL)/auth/login")!
            var urlRequest = URLRequest(url: url)
            urlRequest.httpMethod = "POST"
            urlRequest.setValue("application/json", forHTTPHeaderField: "Content-Type")
            urlRequest.httpBody = try JSONEncoder().encode(request)
            
            // Увеличиваем timeout для медленного соединения
            urlRequest.timeoutInterval = 30
            
            let (data, response) = try await URLSession.shared.data(for: urlRequest)
            
            if let httpResponse = response as? HTTPURLResponse {
                switch httpResponse.statusCode {
                case 200:
                    let authResponse = try JSONDecoder().decode(AuthResponse.self, from: data)
                    
                    await MainActor.run {
                        self.currentUser = authResponse.user
                        self.isAuthenticated = true
                        self.isLoading = false
                        
                        // Сохраняем токены
                        self.userDefaults.set(authResponse.accessToken, forKey: "accessToken")
                        self.userDefaults.set(authResponse.refreshToken, forKey: "refreshToken")
                        self.userDefaults.set(try? JSONEncoder().encode(authResponse.user), forKey: "user")
                    }
                case 401:
                    await MainActor.run {
                        self.errorMessage = "Неверный email или пароль"
                        self.isLoading = false
                    }
                case 404:
                    await MainActor.run {
                        self.errorMessage = "Сервер недоступен"
                        self.isLoading = false
                    }
                default:
                    await MainActor.run {
                        self.errorMessage = "Ошибка сервера: \(httpResponse.statusCode)"
                        self.isLoading = false
                    }
                }
            } else {
                await MainActor.run {
                    self.errorMessage = "Неверный ответ сервера"
                    self.isLoading = false
                }
            }
        } catch {
            await MainActor.run {
                if let urlError = error as? URLError {
                    switch urlError.code {
                    case .notConnectedToInternet:
                        self.errorMessage = "Нет подключения к интернету"
                    case .timedOut:
                        self.errorMessage = "Превышено время ожидания"
                    case .cannotFindHost:
                        self.errorMessage = "Сервер недоступен"
                    default:
                        self.errorMessage = "Ошибка подключения: \(urlError.localizedDescription)"
                    }
                } else {
                    self.errorMessage = "Ошибка подключения: \(error.localizedDescription)"
                }
                self.isLoading = false
            }
        }
    }
    
    func register(username: String, email: String, password: String) async {
        await MainActor.run {
            isLoading = true
            errorMessage = nil
        }
        
        do {
            let request = RegisterRequest(username: username, email: email, password: password)
            let url = URL(string: "\(baseURL)/auth/register")!
            var urlRequest = URLRequest(url: url)
            urlRequest.httpMethod = "POST"
            urlRequest.setValue("application/json", forHTTPHeaderField: "Content-Type")
            urlRequest.httpBody = try JSONEncoder().encode(request)
            
            let (data, response) = try await URLSession.shared.data(for: urlRequest)
            
            if let httpResponse = response as? HTTPURLResponse, httpResponse.statusCode == 201 {
                let authResponse = try JSONDecoder().decode(AuthResponse.self, from: data)
                
                await MainActor.run {
                    self.currentUser = authResponse.user
                    self.isAuthenticated = true
                    self.isLoading = false
                    
                    // Сохраняем токены
                    self.userDefaults.set(authResponse.accessToken, forKey: "accessToken")
                    self.userDefaults.set(authResponse.refreshToken, forKey: "refreshToken")
                    self.userDefaults.set(try? JSONEncoder().encode(authResponse.user), forKey: "user")
                }
            } else {
                await MainActor.run {
                    self.errorMessage = "Ошибка регистрации"
                    self.isLoading = false
                }
            }
        } catch {
            await MainActor.run {
                self.errorMessage = "Ошибка подключения"
                self.isLoading = false
            }
        }
    }
    
    func logout() {
        userDefaults.removeObject(forKey: "accessToken")
        userDefaults.removeObject(forKey: "refreshToken")
        userDefaults.removeObject(forKey: "user")
        
        isAuthenticated = false
        currentUser = nil
    }
    
    func getAccessToken() -> String? {
        return userDefaults.string(forKey: "accessToken")
    }
}
